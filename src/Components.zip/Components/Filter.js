
import React from 'react';
import queryString from 'query-string';
import "../Styles/Filter.css";
import axios from 'axios';

class Filter extends React.Component {
  constructor(){
    super();
    this.state = {
      restaurants: [],
      locations:[],
      location:undefined,
      mealtype:undefined,
      cuisine:[],
      lcost:undefined,
      hcost:undefined,
      sort:undefined,
      page:undefined
    }
  }
  componentDidMount(){
    const qs = queryString.parse(this.props.location.search);
    const { mealtypes, locations, min_price }=qs;

    const filterObj = {
      mealtype: mealtypes,
      location: locations
    }
    axios({
      url:"http://localhost:1997/filter",
      method:'POST',
      header:{'Content-Type':'application/json'},
      data: filterObj

  })
  .then(response=>{ this.setState({ restaurants : response.data.restaurants , mealtype:mealtypes,  location:locations }) 
})
  .catch()

  
  axios({
    url:"http://localhost:1997/locations",
    method:'GET',
    header:{'Content-Type':'application/json'}
})
.then(response=>{ this.setState({ locations : response.data.locations}) })
.catch()
  }

  handleLocationChange = (event)=> {
    const location = event.target.value;
    const {mealtype , cuisine, lcost, hcost, sort, page} = this.state
    const filterObj = {
          location: location,
           mealtype :mealtype,
           cuisine : cuisine.length == 0 ? undefined : cuisine,
           lcost,
           hcost,
           sort, 
           page

    }
    axios({
      url:"http://localhost:1997/filter",
      method:'POST',
      header:{'Content-Type':'application/json'},
      data: filterObj

  })
  .then(response=>{ this.setState({ restaurants : response.data.restaurants, location}) 
})
  .catch()

  this.props.history.push(`/filter?mealtypes=${mealtype}&location=${location}`);
 }
 handleSortChange= (sort)=>{
  const {mealtypes , locations, cuisine, lcost,  hcost, page} = this.state
  const filterObj = {
        location: locations,
         mealtype :mealtypes,
         cuisine : cuisine,
         lcost,
         hcost,
         sort, 
         page

  }
  axios({
    url:"http://localhost:1997/filter",
    method:'POST',
    header:{'Content-Type':'application/json'},
    data: filterObj

})
.then(response=>{ this.setState({ restaurants : response.data.restaurants , mealtype:mealtypes,  location:locations }) 
})
.catch()
 }

handleCostChange = (lcost , hcost)=>{

  const {mealtypes , locations, sort, cuisine, page, min_price} = this.state

 

  
  const filterObj = {
        location: locations,
         mealtype :mealtypes,
         cuisine : cuisine.length == 0 ? undefined : cuisine,
         lcost,
         hcost,
         sort, 
         page

  }
  axios({
    url:"http://localhost:1997/filter",
    method:'POST',
    header:{'Content-Type':'application/json'},
    data: filterObj

})
.then(response=>{ this.setState({ restaurants : response.data.restaurants , lcost: min_price, hcost: min_price }) 
})
.catch()

handleCuisineChange = (cuisineId)=>{
const {mealtypes , locations,  lcost,  hcost, page} = this.state
const filterObj = {
      location: locations,
       mealtype :mealtypes,
       cuisine : cuisine,
       lcost,
       hcost,
       sort, 
       page

}
axios({
  url:"http://localhost:1997/filter",
  method:'POST',
  header:{'Content-Type':'application/json'},
  data: filterObj

})
.then(response=>{ this.setState({ restaurants : response.data.restaurants , cuisine }) 
})
.catch()
}


}



 

  render() {
    const { restaurants ,locations }=this.state;
    return (
      <div>
        <div id="fheader">
          <span className="edureka">
            <a className="logo" href="#">e!</a>
          </span>
          <div className="container-fluid background-image">
            <div className="row">
              <div className="col-3"></div>
              <div className="col-5 text-end pt-4">
                <a href="#" className="login">login</a>
              </div>
              <div className="col-1 text-end pt-4">
                <a href="#" className="account">createaccount</a>
              </div>
              <div className="col-3"></div>
            </div>
          </div>
        </div>

        <div className="container">
          <div className="fheading">Breakfast Places in Mumbai</div>

          <div className="row">
            <div className="col-lg-3 col-sm-12">
              <div className="collapse-filter-block">
                <div className="collapse-head">Filters/Sort</div>
                <div className="fas fa-chevron-down down-arrow me-3 mt-2 chervon"
                  data-bs-toggle="collapse" data-bs-target="#filter" aria-expanded="false"></div>
              </div>
              <div className="filtercontainer" id="filter">
                <div className="filter-heading">Filters</div>
                <div className="Select-Location"> <label>Select Location</label></div>
                <select className="dropdown" onChange={this.handleLocationChange}>
                                                                                        <option value="0">Please select a location</option>
                                                                                        {locations.map((locations, index ) => {
                                return <option key={locations.location_id} value={locations.location_id}>{`${locations.name}, ${locations.city}`}</option>
                            })}
                                                                                        

                                                                                </select>
                <div className="subhead">Cuisine</div>
                <div className="checkbox">
                  <label><input type="checkbox" name="cuisine" value="" onChange={()=> this. handleCuisineChange(1)}/>North Indian</label>
                </div>
                <div className="checkbox">
                  <label><input type="checkbox" name="cuisine" value=""  onChange={()=> this. handleCuisineChange(2)}/>South Indian</label>
                </div>
                <div className="checkbox">
                  <label><input type="checkbox" name="cuisine" value=""  onChange={()=> this. handleCuisineChange(3)}/>Chinese</label>
                </div>
                <div className="checkbox">
                  <label><input type="checkbox" name="cuisine" value="" onChange={()=> this. handleCuisineChange(4)} />Fast Food</label>
                </div>
                <div className="checkbox">
                  <label><input type="checkbox" name="cuisine" value=""  onChange={()=> this. handleCuisineChange(5)}/>Street Food</label>
                </div>

                <div className="subhead">Cost for two</div>
                <div className="checkbox">
                  <label><input type="radio" name="optradio" onChange={()=>this.handleCostChange(1,500)} />Less than ₹500</label>
                </div>
                <div className="checkbox">
                  <label><input type="radio" name="optradio" onChange={()=>this.handleCostChange(500,1000)} />₹500 to ₹1000</label>
                </div>
                <div className="checkbox">
                  <label><input type="radio" name="optradio" onChange={()=>this.handleCostChange(1000,1500)}/>₹1000 to ₹1500</label>
                </div>
                <div className="checkbox">
                  <label><input type="radio" name="optradio" onChange={()=>this.handleCostChange(1500,2000)} />₹1500 to ₹2000</label>
                </div>
                <div className="checkbox">
                  <label><input type="radio" name="optradio" onChange={()=>this.handleCostChange(20000,50000)} />₹2000+</label>
                </div>

                <div className="subhead">Sort</div>
                <div className="checkbox">
                  <label><input type="radio" name="sort"  onChange={()=>this.handleSortChange(1)}/>Price low to high</label>
                </div>
                <div className="checkbox">
                  <label><input type="radio" name="sort" onChange={()=>this.handleSortChange(-1)}/>Price high to low</label>
                </div>
              </div>
            </div>

            <div className="col-lg-9 col-sm-12">
              {restaurants.length > 0 ? restaurants.map((item, index)=>{
                return               <div className="item" key={item,index }>
                <div className="row">
                  <div className="col-3 col-sm-3">
                    <img className="img" src="./Assets/bakeshop.png" alt="image" />
                  </div>
                  <div className="col-9 col-sm-9">
                    <div className="head1">{item.name}</div>
                    <div className="head2">{item.locality}</div>
                    <div className="head3">{item.city}</div>
                  </div>
                  <div className="col-12">
                    <hr />
                  </div>
                  <div className="col-4 col-sm-4">
                    <div className="ms-4 mt-4 cuisine">CUISINES:</div>
                    <div className="ms-4 cuisine">COST FOR TWO:</div>
                  </div>
                  <div className="col-8 col-sm-8">
                    <div className="mt-4 cuisine">{item.cuisine.map((val)=>`${val.name}, `)}</div>
                    <div className="cuisine">{item.min_price}</div>
                  </div>
                </div>
              </div>
              }) : <div className="records">No Records Found</div>}


             
              <div className="row">
                { restaurants.length > 0 ? <div className="pagination" className="mt-2 col-lg-12 col-sm-12">
                  <span className="pagination-item">&#60;</span>
                  <span className="pagination-item">1</span>
                  <span className="pagination-item">2</span>
                  <span className="pagination-item">3</span>
                  <span className="pagination-item">4</span>
                  <span className="pagination-item">5</span>
                  <span className="pagination-item">&#62;</span>

                </div> : null}
              </div>
            </div>
          </div>
        </div>
      </div>
  
    )
  }
}

export default Filter;
