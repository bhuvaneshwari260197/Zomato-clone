import React from 'react';
import "../Styles/home.css";
class Wallpaper extends React.Component {
        handleLocationChange=( event) =>{
                const locId = event.target.value;
                sessionStorage.setItem('locationId', locId);

        }

        render() {
                const { locationsData }= this.props;
                return (
                        <div>
                                <div className="container-fluid background-image">

                                        <img src="./Assets/image.png" height="500" width="100%" alt="" />
                                        <div class="wallpaper-content">
                                                <div className="row">

                                                        <div className="col-3"></div>
                                                        <div className="col-5 text-end pt-4">
                                                                <a href="#" className="login">login</a>
                                                        </div>
                                                        <div className="col-1 text-end pt-4">
                                                                <a href="#" className="account">createaccount</a>
                                                        </div>
                                                        <div className="col-3"></div>
                                                </div>

                                                <div className="row text-center px-4">
                                                        <div className="col-12 pt-5  px-3 py-3">
                                                                <p className="hlogo">e!</p>
                                                        </div>
                                                        <div className="row text-center">
                                                                <div className="col-12 pt-4">
                                                                        <p className="header">Find the best restaurents,cafes and bars</p>
                                                                </div>
                                                                <div className="row">
                                                                        <div className="col-lg-3 col-md-1 col-sm-0"></div>
                                                                        <div className="col-lg-3 col-md-4 col-sm-6 text-end pt-4 ">
                                                                                <select className="dropdown" onChange={this.handleLocationChange}>
                                                                                        <option value="0">Please select a location</option>
                                                                                        {locationsData.map((locations, index ) => {
                                return <option key={locations.location_id} value={locations.location_id}>{`${locations.name}, ${locations.city}`}</option>
                            })}
                                                                                        

                                                                                </select>
                                                                        </div>
                                                                        <div className="col-lg-3 col-md-4 col-sm-6 text-start pt-4 ">

                                                                                <input type="text" placeholder="Search for Restaurents" className="search" />
                                                                        </div>
                                                                        <div className="col-lg-3 col-md-1 col-sm-0"></div>
                                                                </div>
                                                        </div>
                                                </div>

                                        </div>
                                </div>

                        </div>


        )
        }
}
export default Wallpaper;